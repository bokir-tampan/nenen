#!/bin/bash

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
plain='\033[0m'
blue='\033[0;34m'
ungu='\033[0;35m'
Green="\033[32m"
Red="\033[31m"
WhiteB="\e[5;37m"
BlueCyan="\e[5;36m"
Green_background="\033[42;37m"
Red_background="\033[41;37m"
Suffix="\033[0m"

function lane() {
  echo -e "${BlueCyan} ————————————————————————————————————————${Suffix}"
}

function LOGO() {
  clear
	echo -e ""
	lane
	echo -e "${ungu}             Potato Tunneling            "
	lane
	echo -e ""
}

function exp_json() {
  echo -e "${yellow}         Expired  :  ${exp}"
}

function xray_json() {
  echo -e "${ungu}                XRAY VLESS${Suffix}"
}

function port_json() {
echo -e ""
echo -e " VLESS"
echo -e ""
echo -e " Remarks       : ${user}"
echo -e " CITY          : $CITY"
echo -e " ISP           : $ISP"
echo -e " Domain        : ${domain}"
echo -e " Port TLS      : ${vlesstls}"
echo -e " Port none TLS : ${vlessnone},2096"
echo -e " Port GRCP     : ${vlesstls}"
echo -e " id            : ${uuid}"
echo -e " Encryption    : none"
echo -e " Network       : ws or grpc"
echo -e " Path          : /vless"
echo -e " serviceName   : vless"
echo -e ""
}

function portlsnone_json() {
echo -e ""
echo -e " VLESS"
echo -e ""
echo -e " Remarks       : ${user}"
echo -e " CITY          : $CITY"
echo -e " ISP           : $ISP"
echo -e " Domain        : ${domain}"
echo -e " Port TLS      : ${vlesstls}"
echo -e " Port none TLS : ${vlessnone},2096"
echo -e " id            : ${uuid}"
echo -e " Encryption    : none"
echo -e " Network       : ws"
echo -e " Path          : /vless"
echo -e ""
}

function portgrpc_json() {
echo -e ""
echo -e " VLESS"
echo -e ""
echo -e " Remarks       : ${user}"
echo -e " CITY          : $CITY"
echo -e " ISP           : $ISP"
echo -e " Domain        : ${domain}"
echo -e " Port GRCP     : ${vlesstls}"
echo -e " id            : ${uuid}"
echo -e " Encryption    : none"
echo -e " Network       : grpc"
echo -e " serviceName   : vless"
echo -e ""
}

function link_json() {
echo -e " Link TLS      : ${vlesslink1}"
lane
echo -e " Link none TLS : ${vlesslink2}"
lane
echo -e " Link GRCP     : ${vlesslink3}"
}

function linktlsnone_json() {
echo -e " Link TLS      : ${vlesslink1}"
lane
echo -e " Link none TLS : ${vlesslink2}"
}

function linkgrpc_json() {
echo -e " Link GRCP     : ${vlesslink3}"
}

function all() {
LOGO
xray_json
lane
port_json
lane
link_json
lane
exp_json
lane
}

function tlsnone() {
LOGO
xray_json
lane
portlsnone_json
lane
linktlsnone_json
lane
exp_json
lane
}

function grpc() {
LOGO
xray_json
lane
portgrpc_json
lane
linkgrpc_json
lane
exp_json
lane
}

if [[ ${1} == "all" ]]; then
  all
fi

if [[ ${1} == "tlsnone" ]]; then
  tlsnone
fi

if [[ ${1} == "grpc" ]]; then
  grpc
fi