#!/bin/bash

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
plain='\033[0m'
blue='\033[0;34m'
ungu='\033[0;35m'
Green="\033[32m"
Red="\033[31m"
WhiteB="\e[5;37m"
BlueCyan="\e[5;36m"
Green_background="\033[42;37m"
Red_background="\033[41;37m"
Suffix="\033[0m"

function lane() {
  echo -e "${BlueCyan} ————————————————————————————————————————${Suffix}"
}

function LOGO() {
  clear
	echo -e ""
	lane
	echo -e "${ungu}             Potato Tunneling            "
	lane
	echo -e ""
}

function custom() {
cat > /root/custom.json<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "${vmessnone}",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/worryfree",
      "type": "none",
      "host": "tsel.me",
      "sni": "tsel.me",
      "tls": "none"
}
EOF
custom="vmess://$(base64 -w 0 /root/custom.json)"
}

function exp_json() {
  echo -e "${yellow}         Expired  :  ${exp}"
}

function xray_json() {
  echo -e "${ungu}                XRAY VMESS${Suffix}"
}

function port_json() {
echo -e ""
echo -e " VMESS"
echo -e ""
echo -e " Remarks       : ${user}"
echo -e " CITY          : $CITY"
echo -e " ISP           : $ISP"
echo -e " Domain        : ${domain}"
echo -e " Port TLS      : ${vmesstls}"
echo -e " Port none TLS : ${vmessnone},2096"
echo -e " Port GRPC     : ${vmesstls}"
echo -e " id            : ${uuid}"
echo -e " alterId       : 0"
echo -e " Security      : auto"
echo -e " network       : ws or grpc"
echo -e " path          : /vmess - /whatever"
echo -e " serviceName   : vmess"
echo -e ""
}

function portlsnone_json() {
echo -e ""
echo -e " VMESS"
echo -e ""
echo -e " Remarks       : ${user}"
echo -e " CITY          : $CITY"
echo -e " ISP           : $ISP"
echo -e " Domain        : ${domain}"
echo -e " Port TLS      : ${vmesstls}"
echo -e " Port none TLS : ${vmessnone},2096"
echo -e " id            : ${uuid}"
echo -e " alterId       : 0"
echo -e " Security      : auto"
echo -e " network       : ws"
echo -e " path          : /vmess - /whatever"
echo -e ""
}

function portgrpc_json() {
echo -e ""
echo -e " VMESS"
echo -e ""
echo -e " Remarks       : ${user}"
echo -e " CITY          : $CITY"
echo -e " ISP           : $ISP"
echo -e " Domain        : ${domain}"
echo -e " Port GRPC     : ${vmesstls}"
echo -e " id            : ${uuid}"
echo -e " alterId       : 0"
echo -e " Security      : auto"
echo -e " network       : grpc"
echo -e " serviceName   : vmess"
echo -e ""
}

function link_json() {
echo -e " link TLS          : ${vmesslink1}"
lane    
echo -e " link none TLS     : ${vmesslink2}"
lane
echo -e " link GRPC         : ${vmesslink3}"
#lane
#echo -e " link WORRY TLS    : ${vmesslink4}"
#lane
#echo -e " link WORRY NO TLS : ${vmesslink5}"
}

function linktlsnone_json() {
echo -e " link TLS          : ${vmesslink1}"
lane    
echo -e " link none TLS     : ${vmesslink2}"
#lane
#echo -e " link WORRY TLS    : ${vmesslink4}"
#lane
#echo -e " link WORRY NO TLS : ${vmesslink5}"
}

function linkgrpc_json() {
echo -e " link GRPC     : ${vmesslink3}"
}

function all() {
LOGO
xray_json
lane
port_json
lane
link_json
lane
exp_json
lane
}

function tlsnone() {
LOGO
xray_json
lane
portlsnone_json
lane
linktlsnone_json
lane
exp_json
lane
}

function grpc() {
LOGO
xray_json
lane
portgrpc_json
lane
linkgrpc_json
lane
exp_json
lane
}

if [[ ${1} == "all" ]]; then
  all
fi

if [[ ${1} == "tlsnone" ]]; then
  tlsnone
fi

if [[ ${1} == "grpc" ]]; then
  grpc
fi