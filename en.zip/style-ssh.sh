#!/bin/bash

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
plain='\033[0m'
blue='\033[0;34m'
ungu='\033[0;35m'
Green="\033[32m"
Red="\033[31m"
WhiteB="\e[5;37m"
BlueCyan="\e[5;36m"
Green_background="\033[42;37m"
Red_background="\033[41;37m"
Suffix="\033[0m"

if [[ -e /usr/sbin/potatonc/slowdns/server.pub && -e /usr/sbin/potatonc/slowdns/nameserver ]]; then
pub=$(cat /usr/sbin/potatonc/slowdns/server.pub)
ns=$(cat /usr/sbin/potatonc/slowdns/nameserver)
fi

function lane() {
echo -e "${BlueCyan} ————————————————————————————————————————${Suffix}"
}

function LOGO() {
  clear
	echo -e ""
	lane
	echo -e "${ungu}             Potato Tunneling            "
	lane
	echo -e ""
}

function exp_json() {
  echo -e "${yellow}         Expired  :  ${exp}"
}

function ssh_json() {
echo -e "${ungu}               SSH/Dropbear            "
}

function datauser_json() {
echo -e " HOST              : $IP_ADDR"
echo -e " NameServer        : ${ns}"
echo -e " Username          : $Login"
echo -e " Password          : $Pass"
echo -e " PUB Key           : ${pub}"
}

function port_json() {
echo -e " OpenSSH           : ${dhs},2222,444"
echo -e " Dropbear          : ${ddb},90,69,143"
echo -e " OpenSSH SSL       : ${sshssl}"
echo -e " Dropbear SSL      : ${dropssl}"
lane
echo -e " SSH WebSocket Direct"
echo -e "  Port : 80,7788,2082,8880"
echo -e "         8181,8282,6602"
echo -e " SSH WebSocket SSL"
echo -e "  Port : 443,8443"
lane
echo -e " SlowDNS           : 53,5300"
echo -e " Squid Proxy       : 8080"
echo -e " OHP + SSH         : 9080"
echo -e " OHP + Dropbear    : 9090"
echo -e " BadVPN UDPGW      : 7100-7600"
}

function payload_json() {
echo -e " Payload SSH CDN Port 80"
echo -e ""
echo -e "${Green}GET / HTTP/1.1"
echo -e "Host: [host_port]"
echo -e "User-Agent: [ua]"
echo -e "Upgrade: websocket[crlf][crlf]${Suffix}"
lane
echo -e " Payload SSH TLS/WSS Port 443"
echo -e ""
echo -e "${Green}GET wss://BUG/ HTTP/1.1"
echo -e "Host: [host]"
echo -e "User-Agent: [ua]"
echo -e "Upgrade: Websocket[crlf][crlf]${Suffix}"
lane
echo -e " Payload SSH WS Non TLS Port 7788"
echo -e " Path - /whatever"
echo -e ""
echo -e "${Green}GET wss://BUG/worryfree HTTP/1.1"
echo -e "Host: [host]"
echo -e "User-Agent: [ua]"
echo -e "Upgrade: Websocket[crlf][crlf]${Suffix}"
lane
echo -e " Payload OHP + SSH Port 9080"
echo -e " Path - /whatever"
echo -e ""
echo -e "${Green}GET https://BUG HTTP/1.1"
echo -e "Host: [host]"
echo -e "User-Agent: [ua][crlf][crlf]${Suffix}"
}

LOGO
ssh_json
lane
datauser_json
lane
port_json
lane
payload_json
lane
exp_json
lane