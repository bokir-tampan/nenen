#!/bin/bash

function custom() {
cat > /root/custom.json<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "${vmessnone}",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/worryfree",
      "type": "none",
      "host": "tsel.me",
      "sni": "tsel.me",
      "tls": "none"
}
EOF
custom="vmess://$(base64 -w 0 /root/custom.json)"
}


function wsbot() {
echo "<code>————————————————————————————————————</code>"
echo "<code>               VMESS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>Remarks        : ${user}"
echo "CITY           : $CITY"
echo "ISP            : $ISP"
echo "Domain         : ${domain}"
echo "Port TLS       : ${vmesstls}"
echo "Port none TLS  : ${vmessnone},2096"
echo "id             : ${uuid}"
echo "alterId        : 0"
echo "Security       : auto"
echo "network        : ws"
echo "path           : /vmess - /whatever"
echo "Expired On     : $exp</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>           VMESS WS TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink1}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>          VMESS WS NO TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink2}</code>"
echo "<code>————————————————————————————————————</code>"
#echo "<code>          VMESS WORRY TLS</code>"
#echo "<code>————————————————————————————————————</code>"
#echo "<code>${vmesslink4}</code>"
#echo "<code>————————————————————————————————————</code>"
#echo "<code>         VMESS WORRY NO TLS</code>"
#echo "<code>————————————————————————————————————</code>"
#echo "<code>${vmesslink5}</code>"
#echo "<code>————————————————————————————————————</code>"
}

function grpcbot() {
echo "<code>————————————————————————————————————</code>"
echo "<code>               VMESS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>Remarks        : ${user}"
echo "CITY           : $CITY"
echo "ISP            : $ISP"
echo "Domain         : ${domain}"
echo "Port GRPC      : ${vmesstls}"
echo "id             : ${uuid}"
echo "alterId        : 0"
echo "Security       : auto"
echo "network        : grpc"
echo "serviceName    : vmess"
echo "Expired On     : $exp</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>             VMESS GRPC</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink3}</code>"
echo "<code>————————————————————————————————————</code>"
}

function allbot() {
echo "<code>————————————————————————————————————</code>"
echo "<code>               VMESS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>Remarks        : ${user}"
echo "CITY           : $CITY"
echo "ISP            : $ISP"
echo "Domain         : ${domain}"
echo "Port TLS       : ${vmesstls}"
echo "Port none TLS  : ${vmessnone},2096"
echo "Port GRPC      : ${vmesstls}"
echo "id             : ${uuid}"
echo "alterId        : 0"
echo "Security       : auto"
echo "network        : ws - grpc"
echo "path           : /vmess - /whatever"
echo "serviceName    : vmess"
echo "Expired On     : $exp</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>           VMESS WS TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink1}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>          VMESS WS NO TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink2}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>             VMESS GRPC</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink3}</code>"
echo "<code>————————————————————————————————————</code>"
#echo "<code>          VMESS WORRY TLS</code>"
#echo "<code>————————————————————————————————————</code>"
#echo "<code>${vmesslink4}</code>"
#echo "<code>————————————————————————————————————</code>"
#echo "<code>         VMESS WORRY NO TLS</code>"
#echo "<code>————————————————————————————————————</code>"
#echo "<code>${vmesslink5}</code>"
#echo "<code>————————————————————————————————————</code>"
}
